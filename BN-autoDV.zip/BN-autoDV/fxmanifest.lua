fx_version 'cerulean'
game 'gta5'

author 'Delbes'
description 'https://lambra.tebex.io'


server_script 'server/main.lua'

lua54 'yes'